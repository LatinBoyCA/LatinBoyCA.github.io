let hoursList = [];
let totalHours = 0;
let totalPay = 0;

function addHours() {
  const hoursWorked = document.getElementById('hours').value;
  const [hours, minutes] = hoursWorked.split(':').map(Number);
  hoursList.push(hours + (minutes / 60));
  updateList();
  updateTotalHours();
  document.getElementById('hours').value = '';
}

function deleteLastEntry() {
  hoursList.pop();
  updateList();
  updateTotalHours();
}

function reset() {
  hoursList = [];
  totalHours = 0;
  totalPay = 0;
  updateList();
  updateTotalHours();
}

function updateList() {
  const listElement = document.getElementById('hours-list');
  const listItems = hoursList.map((hours) => {
    const hoursDisplay = Math.floor(hours);
    const minutesDisplay = Math.round((hours - hoursDisplay) * 60);
    return `<li>${hoursDisplay}:${minutesDisplay.toString().padStart(2, '0')} hours</li>`;
  });
  listElement.innerHTML = listItems.join('');
}

function updateTotalHours() {
  totalHours = hoursList.reduce((acc, curr) => acc + curr, 0);
  totalPay = totalHours * 20;
  document.getElementById('total-hours').innerHTML = `TOTAL DE HORAS: ${Math.floor(totalHours)}:${Math.round((totalHours - Math.floor(totalHours)) * 60).toString().padStart(2, '0')}`;
  document.getElementById('total-pay').innerHTML = `TOTAL DE PAGO: $${totalPay.toFixed(2)}`;
}

function generatePDF() {
  const doc = new jspdf.jsPDF();
  doc.text('Work Hours Report', 10, 10);
  hoursList.forEach((hours) => {
    const hoursDisplay = Math.floor(hours);
    const minutesDisplay = Math.round((hours - hoursDisplay) * 60);
    doc.text(`${hoursDisplay}:${minutesDisplay.toString().padStart(2, '0')} hours`, 10, 20);
  });
  doc.text(`TOTAL DE HORAS: ${Math.floor(totalHours)}:${Math.round((totalHours - Math.floor(totalHours)) * 60).toString().padStart(2, '0')}`, 10, 30);
  doc.text(`TOTAL DE PAGO: $${totalPay.toFixed(2)}`, 10, 40);
  doc.save('work-hours-report.pdf');
}
function generatePDF() {
  const doc = new jsPDF();
  doc.text('Work Hours Report', 10, 10);
  hoursList.forEach((hours) => {
    const hoursDisplay = Math.floor(hours);
    const minutesDisplay = Math.round((hours - hoursDisplay) * 60);
    doc.text(`${hoursDisplay}:${minutesDisplay.toString().padStart(2, '0')} hours`, 10, 20);
  });
  doc.text(`Total Hours: ${Math.floor(totalHours)}:${totalMinutes.toString().padStart(2, '0')}`, 10, 30);
  doc.save('work-hours-report.pdf');
}